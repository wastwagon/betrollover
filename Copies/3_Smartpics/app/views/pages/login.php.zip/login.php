<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartPicks Pro - Login</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="login-wrapper">
        <div class="login-background">
            <div class="background-overlay"></div>
        </div>
        
        <div class="login-container">
            <div class="login-header">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="fas fa-futbol"></i>
                    </div>
                    <h1>SmartPicks Pro</h1>
                    <p>Professional Football Betting Platform</p>
                </div>
            </div>
            
            <div class="login-form-container">
                <?php if (isset($error) && $error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <?= ViewHelper::e($error) ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($success) && $success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <?= ViewHelper::e($success) ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" class="login-form">
                    <div class="form-group">
                        <label for="username">
                            <i class="fas fa-user"></i>
                            Username
                        </label>
                        <input type="text" id="username" name="username" 
                               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" 
                               placeholder="Enter your username" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">
                            <i class="fas fa-lock"></i>
                            Password
                        </label>
                        <input type="password" id="password" name="password" 
                               placeholder="Enter your password" required>
                    </div>
                    
                    <button type="submit" class="login-btn">
                        <i class="fas fa-sign-in-alt"></i>
                        Sign In
                    </button>
                </form>
                
                <div class="login-footer">
                    <div class="credentials-info">
                        <h4><i class="fas fa-key"></i> Demo Credentials</h4>
                        <div class="credential-item">
                            <span class="label">Username:</span>
                            <span class="value">admin</span>
                        </div>
                        <div class="credential-item">
                            <span class="label">Password:</span>
                            <span class="value">password</span>
                        </div>
                    </div>
                    
                    <div class="register-link">
                        <p>Don't have an account?</p>
                        <a href="/register" class="register-btn">
                            <i class="fas fa-user-plus"></i>
                            Create Account
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

.login-wrapper {
    position: relative;
    width: 100%;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

.login-background {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    z-index: 0;
}

.background-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="50" cy="50" r="1" fill="rgba(255,255,255,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
    opacity: 0.3;
}

.login-container {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(20px);
    border-radius: 20px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
    padding: 40px;
    width: 100%;
    max-width: 450px;
    position: relative;
    z-index: 1;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.login-header {
    text-align: center;
    margin-bottom: 40px;
}

.logo {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.logo-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 20px;
    box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
}

.logo-icon i {
    font-size: 36px;
    color: white;
}

.logo h1 {
    font-size: 32px;
    font-weight: 700;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 8px;
}

.logo p {
    color: #666;
    font-size: 16px;
    font-weight: 400;
}

.login-form-container {
    width: 100%;
}

.alert {
    padding: 15px 20px;
    border-radius: 10px;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 14px;
    font-weight: 500;
}

.alert-error {
    background: rgba(220, 53, 69, 0.1);
    color: #dc3545;
    border: 1px solid rgba(220, 53, 69, 0.2);
}

.alert-success {
    background: rgba(40, 167, 69, 0.1);
    color: #28a745;
    border: 1px solid rgba(40, 167, 69, 0.2);
}

.login-form {
    margin-bottom: 30px;
}

.form-group {
    margin-bottom: 25px;
}

.form-group label {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
    font-weight: 600;
    color: #333;
    font-size: 14px;
}

.form-group label i {
    color: #667eea;
    width: 16px;
}

.form-group input {
    width: 100%;
    padding: 15px 20px;
    border: 2px solid #e1e5e9;
    border-radius: 12px;
    font-size: 16px;
    transition: all 0.3s ease;
    background: rgba(255, 255, 255, 0.8);
}

.form-group input:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    background: white;
}

.form-group input::placeholder {
    color: #999;
}

.login-btn {
    width: 100%;
    padding: 18px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
}

.login-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 35px rgba(102, 126, 234, 0.4);
}

.login-btn:active {
    transform: translateY(0);
}

.login-footer {
    border-top: 1px solid rgba(0, 0, 0, 0.1);
    padding-top: 25px;
}

.credentials-info {
    background: rgba(102, 126, 234, 0.05);
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 25px;
    border: 1px solid rgba(102, 126, 234, 0.1);
}

.credentials-info h4 {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 15px;
    color: #333;
    font-size: 16px;
    font-weight: 600;
}

.credentials-info h4 i {
    color: #667eea;
}

.credential-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
}

.credential-item:last-child {
    border-bottom: none;
}

.credential-item .label {
    font-weight: 500;
    color: #666;
}

.credential-item .value {
    font-weight: 600;
    color: #333;
    background: rgba(102, 126, 234, 0.1);
    padding: 4px 12px;
    border-radius: 6px;
    font-size: 14px;
}

.register-link {
    text-align: center;
}

.register-link p {
    color: #666;
    margin-bottom: 15px;
    font-size: 14px;
}

.register-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    background: transparent;
    color: #667eea;
    border: 2px solid #667eea;
    border-radius: 10px;
    text-decoration: none;
    font-weight: 600;
    font-size: 14px;
    transition: all 0.3s ease;
}

.register-btn:hover {
    background: #667eea;
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
}

/* Responsive Design */
@media (max-width: 480px) {
    .login-container {
        margin: 20px;
        padding: 30px 25px;
        border-radius: 15px;
    }
    
    .logo h1 {
        font-size: 28px;
    }
    
    .logo-icon {
        width: 70px;
        height: 70px;
    }
    
    .logo-icon i {
        font-size: 32px;
    }
    
    .form-group input {
        padding: 14px 18px;
        font-size: 15px;
    }
    
    .login-btn {
        padding: 16px;
        font-size: 15px;
    }
}

/* Animation */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.login-container {
    animation: fadeInUp 0.6s ease-out;
}

/* Dark mode support */
@media (prefers-color-scheme: dark) {
    .login-container {
        background: rgba(26, 32, 44, 0.95);
        border: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .logo h1 {
        background: linear-gradient(135deg, #81c784 0%, #4fc3f7 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    .logo p {
        color: #a0aec0;
    }
    
    .form-group label {
        color: #e2e8f0;
    }
    
    .form-group input {
        background: rgba(45, 55, 72, 0.8);
        border-color: #4a5568;
        color: #e2e8f0;
    }
    
    .form-group input:focus {
        border-color: #81c784;
        background: rgba(45, 55, 72, 1);
    }
    
    .credentials-info {
        background: rgba(81, 195, 247, 0.05);
        border-color: rgba(81, 195, 247, 0.1);
    }
    
    .credentials-info h4 {
        color: #e2e8f0;
    }
    
    .credential-item .label {
        color: #a0aec0;
    }
    
    .credential-item .value {
        color: #e2e8f0;
        background: rgba(81, 195, 247, 0.1);
    }
    
    .register-link p {
        color: #a0aec0;
    }
}
</style>
